$batUrl = "http://xxx/test.bat"
$tmpBat = Join-Path $env:TEMP "run.bat"
try {
    Invoke-RestMethod -Uri $batUrl -OutFile $tmpBat
    cmd /c "`"$tmpBat`""
}
catch {
    Write-Host "Error：$_" -ForegroundColor Red
}