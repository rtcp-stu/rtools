@echo off
cls
echo -------------------------------------------------
echo            Welcome to RTCP_Studio Tools 
echo                         For jetbrains
echo -------------------------------------------------
setlocal enabledelayedexpansion
:start
set "input="
set /p "input=Please input your ID Code  :"

set "len=0"
:count_len
if not "!input:~%len%!"=="" set /a len+=1 & goto count_len
if not !len! equ 12 (
    echo Error!len!
    goto start
)

set "numCheck=!input!"
for /l %%i in (0,1,9) do (
    set "numCheck=!numCheck:%%i=!"
)
if not "!numCheck!"=="" (
    echo Error
    goto start
)
endlocal
echo Please Wait.....
cscript //nologo %~dp0\scripts\install.vbs
< %~dp0\code.txt clip
start %~dp0\code.html
pause